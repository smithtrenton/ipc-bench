"""Multiprocessing pipe benchmark package."""
