"""Python benchmark method packages."""
