"""Multiprocessing queue benchmark package."""
