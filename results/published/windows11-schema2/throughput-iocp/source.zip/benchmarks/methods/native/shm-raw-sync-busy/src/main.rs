fn main() {
    if let Err(error) = support::run_raw_sync_shared_memory(support::RawSyncMethod::Busy) {
        eprintln!("{error}");
        std::process::exit(1);
    }
    support::worker_finished();
}
